<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Color Select</title>

    <link rel="stylesheet" href="<?php echo site_url()?>asset/css/bootstrap.min.css" />
    <script src="<?php echo site_url()?>asset/js/bootstrap.min.js"></script>
    <script src="<?php echo site_url()?>asset/js/jquery.min.js"></script>

    <link rel="stylesheet" type="text/css" href="<?php site_url()?>asset/jquery-ui-1.12.1/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="<?php site_url()?>asset/tokenfield/dist/css/bootstrap-tokenfield.min.css">
    <script src="<?php echo site_url()?>asset/jquery-ui-1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo site_url()?>asset/tokenfield/dist/bootstrap-tokenfield.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h4 class="text-center pt-3">Color Selection</h4>
                <hr>
                <span class="text-danger"><?php echo validation_errors(); ?></span>
                <?php if($this->session->flashdata('message')):?>
                    <span class="text-success"><?php echo $this->session->flashdata('message')?></span>
                <?php endif;?>
                <form method="post" id="color_form" action="<?php echo site_url()?>insert_color">
                    <div class="form-group">
                        <label for="">Select Color</label>
                        <input type="text" name="color" id="color" class="form-control" />
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
                    </div>
                </form>
            </div>
        </div>
    </div>



    <script>
        $(document).ready(function(){

            $('#color').tokenfield({
                autocomplete:{
                    source: ['Maroon','Brown','Olive','Teal','Navy','Black','Red','Orange','Yellow','Lime','Green','Cyan','Blue','Purple','Magenta','Grey','Pink','Apricot','Beige','Mint','Lavender','White'],
                    delay:100
                },
                showAutocompleteOnFocus: true
            });

        });

    </script>
</body>
</html>