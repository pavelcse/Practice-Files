<html>
<head>
    <!-- <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Color Select</title> -->

    <link rel="stylesheet" href="<?php echo site_url()?>asset/css/bootstrap.min.css" />
    <script src="<?php echo site_url()?>asset/js/bootstrap.min.js"></script>
    <script src="<?php echo site_url()?>asset/js/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <h4 class="text-center pt-3">Select Variant</h4>
                <hr>

                <span id="" class="text-danger"><?php echo validation_errors(); ?></span>
                <?php if($this->session->flashdata('message')):?>
                    <span id="" class="text-success"><?php echo $this->session->flashdata('message')?></span>
                <?php endif;?>

                <div class="form-group">
                    <select class="form-control" id="variant" name="variant" onchange="java_script_:show(this.options[this.selectedIndex].value)">
                        <option value="">Select Vatiant</option>
                        <option id="" value="Color">Color</option>
                        <option id="" value="Size">Size</option>
                        <option id="" value="Color & Size">Color & Size</option>
                    </select>
                </div>
            </div>
        </div>
        <!-- For Color Variant -->
        <div class="row" id="color_variant">
            <div class="col">
                <h4 class="text-center pt-3">Color Selection</h4>
                <hr>
                <form method="post" id="color_form" action="<?php echo site_url()?>insert_color_variant">
                    <div class="form-group" id="color-container">
                        <label for="">Select Color</label>
                        <input type="text" name="color[]" class="form-control">
                    </div>
                    <div class="form-group">
                        <input class="more_color" type="button" value="Addmore" name="addmore" />
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
                    </div>
                </form>
            </div>
        </div>
        <?php
            if(isset($color_variant) && isset($size_variant) == null){
            ?>
                        <div class="row">
            <div class="col">
                <h4>For Color Variant</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Remove</th>
                            <th>Color</th>
                            <th>Your Price</th>
                            <th>Sale Price</th>
                            <th>Sale Start Date</th>
                            <th>Sale End Date</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $id = ''; ?>
                        <?php foreach ($color_variant as $color): ?>
                            <?php $id++; ?>
                        <tr id="fild<?php echo $id; ?>">
                            <td><button id="del<?php echo $id; ?>" class="btn btn-danger btn-sm">Remove</button></td>
                            <td><?php echo $color; ?></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input id="datepickerstart<?php echo $id; ?>" type="text"></td>
                            <td><input id="datepickerend<?php echo $id; ?>" type="text"></td>
                            <td><input type="number"></td>
                        </tr>
                        <script>
                            $("#checkAll").click(function () {
                                 $('input:checkbox').not(this).prop('checked', this.checked);
                             });

                            $( function() {
                                $( "#datepickerstart<?php echo $id; ?>" ).datepicker();
                                $( "#datepickerend<?php echo $id; ?>" ).datepicker();
                            });

                            $('#del<?php echo $id; ?>').click(function() {
                                $("#fild<?php echo $id; ?>").remove();
                            });

                        </script>
                        <?php endforeach; ?>
                    </tbody>                
                </table>
            </div>
        </div>
            <?php    
            }
            ?>



            <?php
            if(isset($size_variant) && isset($color_variant) == null){
            ?>
                        <div class="row">
            <div class="col">
                <h4>For Color Variant</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Remove</th>
                            <th>Size</th>
                            <th>Your Price</th>
                            <th>Sale Price</th>
                            <th>Sale Start Date</th>
                            <th>Sale End Date</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $id = ''; ?>
                        <?php foreach ($size_variant as $size): ?>
                            <?php $id++; ?>
                        <tr id="fild<?php echo $id; ?>">
                            <td><button id="del<?php echo $id; ?>" class="btn btn-danger btn-sm">Remove</button></td>
                            <td><?php echo $size; ?></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input id="datepickerstart<?php echo $id; ?>" type="text"></td>
                            <td><input id="datepickerend<?php echo $id; ?>" type="text"></td>
                            <td><input type="number"></td>
                        </tr>
                        <script>
                            $("#checkAll").click(function () {
                                 $('input:checkbox').not(this).prop('checked', this.checked);
                             });

                            $( function() {
                                $( "#datepickerstart<?php echo $id; ?>" ).datepicker();
                                $( "#datepickerend<?php echo $id; ?>" ).datepicker();
                            });

                            $('#del<?php echo $id; ?>').click(function() {
                                $("#fild<?php echo $id; ?>").remove();
                            });

                        </script>
                        <?php endforeach; ?>
                    </tbody>                
                </table>
            </div>
        </div>
            <?php    
            }
            ?>
        

        <?php if(isset($color_variant) && isset($size_variant)): ?>
        <div class="row">
            <div class="col">
                <h4>For Color & Size Variant</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Remove</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Your Price</th>
                            <th>Sale Price</th>
                            <th>Sale Start Date</th>
                            <th>Sale End Date</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($color_variant as $color): ?>
                            <?php foreach($size_variant as $size): ?>
                        <tr>
                            <td><button class="btn btn-danger btn-sm">Remove</button></td>
                            <td><?php echo $color; ?></td>
                            <td><?php echo $size; ?></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input type="date"></td>
                            <td><input type="date"></td>
                            <td><input type="number"></td>
                        </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>                
                </table>
            </div>
        </div>
        <?php endif;?>
        <!-- For Size Variant -->
        <div class="row" id="size_variant">
            <div class="col">
                <h4 class="text-center pt-3">Size Selection</h4>
                <hr>
                <form method="post" id="color_form" action="<?php echo site_url()?>insert_size_variant">
                    <div class="form-group" id="size-container">
                        <label for="">Select Size</label>
                        <input type="text" name="size[]" class="form-control">
                    </div>
                    <div class="form-group">
                        <input class="more_size" type="button" value="Addmore" name="addmore" />
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
                    </div>
                </form>
            </div>
        </div>
        <!-- For Color & Size Variant -->
        <div class="row" id="color_size_variant">
            <div class="col">
                <h4 class="text-center pt-3">Color & Size Selection</h4>
                <hr>
                <form method="post" id="color_form" action="<?php echo site_url()?>insert_color_size_variant">

                    <div class="form-group" id="color_size_container_c">
                        <label for="">Select Color</label>
                        <input type="text" name="color[]" id="color_v" class="form-control" />
                    </div>

                    <div class="form-group">
                        <input class="more_color_c" type="button" value="Addmore" name="addmore" />
                    </div>

                    <div class="form-group" id="color_size_container_s">
                        <label for="">Select Size</label>
                        <input type="text" name="size[]" id="size_v" class="form-control" />
                    </div>

                    <div class="form-group">
                        <input class="more_size_s" type="button" value="Addmore" name="addmore" />
                    </div>

                    <div class="form-group">
                        <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
                    </div>
                </form>
            </div>
        </div>

    <!-- Variant Selection -->
    <script>
        $(function() {
            $('#color_variant').hide(); 
            $('#size_variant').hide(); 
            $('#color_size_variant').hide(); 

            $('#variant').change(function(){
                //For Color Variant
                if($('#variant').val() == 'Color') {
                    $('#color_variant').show(); 
                } else {
                    $('#color_variant').hide(); 
                }
                //For Size Variant
                if($('#variant').val() == 'Size') {
                    $('#size_variant').show(); 
                } else {
                    $('#size_variant').hide(); 
                } 
                //For Color & Size Variant
                if($('#variant').val() == 'Color & Size') {
                    $('#color_size_variant').show(); 
                } else {
                    $('#color_size_variant').hide(); 
                }  
            });
        });
    </script>

    <script>
        $('.more_color').click(function () {
            $('#color-container').append("<span class='d-flex flex-row align-items-center'><input type='text' name='color[]' class='form-control mt-2'><h3 class='red-text' style='cursor: pointer;' onclick='$(this).parent().remove()'><img src='<?php echo base_url();?>asset/img/cross_icon.png' alt='' width='22px'></h3></span>");
        });

        $('.more_size').click(function () {
            $('#size-container').append("<span class='d-flex flex-row align-items-center'><input type='text' name='size[]' class='form-control mt-2'><h3 class='red-text' style='cursor: pointer;' onclick='$(this).parent().remove()'><img src='<?php echo base_url();?>asset/img/cross_icon.png' alt='' width='22px'></h3></span>");
        });

        $('.more_color_c').click(function () {
            $('#color_size_container_c').append("<span class='d-flex flex-row align-items-center'><input type='text' name='color[]' class='form-control mt-2'><h3 class='red-text' style='cursor: pointer;' onclick='$(this).parent().remove()'><img src='<?php echo base_url();?>asset/img/cross_icon.png' alt='' width='22px'></h3></span>");
        });

        $('.more_size_s').click(function () {
            $('#color_size_container_s').append("<span class='d-flex flex-row align-items-center'><input type='text' name='size[]' class='form-control mt-2'><h3 class='red-text' style='cursor: pointer;' onclick='$(this).parent().remove()'><img src='<?php echo base_url();?>asset/img/cross_icon.png' alt='' width='22px'></h3></span>");
        });
    </script>
</body>
</html>