<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class variant_model extends CI_Model {

    public function insert_color_variant()
    {
    	$getColor = implode(',',$this->input->post('color'));
        $color =
            [
                'color_name' => $getColor
            ];

        $result = $this->db->insert('colors', $color);
        return $result;
    }

    public function insert_size_variant()
    {
    	$getSize = implode(',',$this->input->post('size'));
        $size =
            [
                'size_name' => $getSize
            ];

        $result = $this->db->insert('size', $size);
        return $result;
    }

    public function insert_color_size_variant()
    {
    	$getSize = implode(',',$this->input->post('size'));
    	$getColor = implode(',',$this->input->post('color'));

        $size =
            [
                'product_id' => '5',
                'size_name' => $getSize
            ];

        $color =
            [
                'product_id' => '5',
                'color_name' => $getColor
            ];

        $result = $this->db->insert('size', $size);
        $result2 = $this->db->insert('colors', $color);
        return true;

    }

    public function get_color_variant()
    {
        $query = $this->db->select('color_name')->where('product_id', 5)->get('colors');
        $result = $query->row();

    	return $getcolor = explode(',', $result->color_name);
    	
    }

    public function get_size_variant()
    {
        $query = $this->db->select('size_name')->where('product_id', 5)->get('size');
        $result = $query->row();

    	return $getcolor = explode(',', $result->size_name);
    	
    }
}
