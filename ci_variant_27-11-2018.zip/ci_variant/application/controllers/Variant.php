<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Variant extends CI_Controller {

    public function index()
    {
        $this->load->view('select_variant_view');
    }

    public function insert_color_variant()
    {
        $this->form_validation->set_rules('color[]', 'Color', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        {
            //redirect($_SERVER['HTTP_REFERER']);
             redirect('Variant');
        }else{
            if ($this->variant_model->insert_color_variant()){


                $this->session->set_flashdata('message', 'Color Inserted....!');

                $data['color_variant'] = $this->variant_model->get_color_variant();
                $this->load->view('select_variant_view', $data);

                //redirect('Variant');
            }else{
                $this->session->set_flashdata('message', 'Color Not Inserted, Please Try Again....!');
                 redirect('Variant');
            }

        }

        $color = $this->input->post('color');
        
    }

    public function insert_size_variant()
    {
        $this->form_validation->set_rules('size[]', 'Size', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        {
            //redirect($_SERVER['HTTP_REFERER']);
             redirect('Variant');
        }else{
            if ($this->variant_model->insert_size_variant()){
                $this->session->set_flashdata('message', 'Size Inserted....!');

                $data['size_variant'] = $this->variant_model->get_size_variant();
                $this->load->view('select_variant_view', $data);
                //redirect('Variant');
            }else{
                $this->session->set_flashdata('message', 'Size Not Inserted, Please Try Again....!');
                 redirect('Variant');
            }
        }
    }

    public function insert_color_size_variant()
    {
        $this->form_validation->set_rules('color[]', 'Color', 'trim|required');
        $this->form_validation->set_rules('size[]', 'Size', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        {
            //redirect($_SERVER['HTTP_REFERER']);
             redirect('Variant');
        }else{
            if ($this->variant_model->insert_color_size_variant()){
                $this->session->set_flashdata('message', 'Color & Size Inserted....!');

                $data['color_variant'] = $this->variant_model->get_color_variant();
                $data['size_variant'] = $this->variant_model->get_size_variant();
                $this->load->view('select_variant_view', $data);
                //redirect('Variant');
            }else{
                $this->session->set_flashdata('message', 'Color and Size Not Inserted, Please Try Again....!');
                 redirect('Variant');
            }
        }
    }
}
