<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class form_model extends CI_Model {

    /**
     * @param $target_file
     * @return mixed
     */
    public function index($target_file)
    {
        $data = [
            'news_title' => $this->input->post('news_title'),
            'news_details' => $this->input->post('news_details'),
            'news_image_location' => $target_file,
            'news_created_date_time' => date('Y-m-d h:i:sa')
        ];

        $insert = $this->db->insert('news', $data);
        return $insert;
    }

    public function check($data)
    {
        $this->db->where('news_title', $data);
        $this->db->from('news');
        $query = $this->db->get();

        if($query->num_rows() > 0)
        {
            return true;
        }else{
            return false;
        }
    }

    public function all_news()
    {
        $query = $this->db->where('news_active', 1)->order_by('news_id', 'desc')->get('news', 3);
        $result = $query->result();
        return $result;
    }

    public function get_news_by_ajax($limit)
    {
        $offset	=DEFAULT_DATA_LIMIT;
        $query = $this->db->where('news_active', 1)->order_by('news_id', 'desc')->get('news',$offset,$limit);
        $result = $query->result();
        return json_encode($result,JSON_HEX_APOS);

        /*$sql="SELECT * FROM news WHERE news_active=1 order by news_id DESC LIMIT $limit,".DEFAULT_DATA_LIMIT."";

        $query=$this->db->query($sql);

        return $query->result_array();*/
    }


    public  function news_details($news_id)
    {
        $this->db->where('news_id', $news_id);
        $this->db->from('news');
        $query = $this->db->get();
        $result = $query->row();
        return $result;
    }

    public  function news_delete($news_id)
    {
        $this->db->where('news_id', $news_id);
        $this->db->set('news_active', '0', false);
        $this->db->update('news');
        return true;
    }

    public function update($target_file, $news_id)
    {
        $data = [
            'news_title' => $this->input->post('news_title'),
            'news_details' => $this->input->post('news_details'),
            'news_image_location' => $target_file
        ];

        $this->db->where('news_id', $news_id);
        $update = $this->db->update('news', $data);
        return $update;
    }
}

