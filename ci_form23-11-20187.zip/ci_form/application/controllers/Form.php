<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends CI_Controller {

    public function index()
    {
        $this->load->view('form');
    }

    public function check_title()
    {
        if(!filter_var($_POST['news_title']))
        {
            echo "<label style='color: red'><span class='glyphicon-glyphicon-remove'></span>Invalid Title</label>";
        }else{
            if($this->form_model->check($_POST['news_title']))
            {
                echo '<label style="color: red"><span class="glyphicon-glyphicon-remove"></span>Title Already Taken</label>';
            }else{
                echo "<label class='text-success'><span class='glyphicon-glyphicon-ok'></span>Title Available</label>";
            }
        }
    }

    public function insert()
    {
        $this->form_validation->set_rules('news_title', 'News Title', 'trim|required|min_length[5]|is_unique[news.news_title]');
        $this->form_validation->set_rules('news_details', 'News Description', 'trim|required|min_length[15]');

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('form');
        }else{

            if(!empty($_FILES['news_image_location']['name'])){
                $target_dir = "asset/image/";
                $target_file = $target_dir . basename($_FILES["news_image_location"]["name"]);
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                    && $imageFileType != "gif" ) {

                    $this->session->set_flashdata('image_message', 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
                    redirect('Form/insert');
                }else {
                    if (move_uploaded_file($_FILES["news_image_location"]["tmp_name"], $target_file)) {
                        $insert = $this->form_model->index($target_file);
                        if($insert){
                            $this->session->set_flashdata('image_message', 'News Save Successfully.');
                            //$this->load->view('form');
                            redirect('Form/show');
                        }
                    } else {
                        $this->session->set_flashdata('image_message', 'Sorry, Something wrong. Please try again');
                        redirect('Form/insert');
                    }
                }
            }else{
                $target_file = "";
                $insert = $this->form_model->index($target_file);
                if($insert){
                    $this->session->set_flashdata('image_message', 'News Save Successfully.');
                    redirect('Form/show');
                }else{
                    $this->session->set_flashdata('image_message', 'Sorry, Something wrong. Please try again');
                    redirect('Form/insert');
                }
            }
        }


        $accepted_origins = array("http://localhost");
        $imageFolder = "asset/image/";
        reset ($_FILES);
        $temp = current($_FILES);
        if (is_uploaded_file($temp['tmp_name'])){
            if (isset($_SERVER['HTTP_ORIGIN'])) {
                // same-origin requests won't set an origin. If the origin is set, it must be valid.
                if (in_array($_SERVER['HTTP_ORIGIN'], $accepted_origins)) {
                    header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
                } else {
                    header("HTTP/1.0 403 Origin Denied");
                    return;
                }
            }

            if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
                header("HTTP/1.0 500 Invalid file name.");
                return;
            }
            // Verify extension
            if (!in_array(strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION)), array("gif", "jpg", "png", "jpeg"))) {
                header("HTTP/1.0 500 Invalid extension.");
                return;
            }

            $filetowrite = $imageFolder . $temp['name'];
            move_uploaded_file($temp['tmp_name'], $filetowrite);
            echo json_encode(array('location' => $filetowrite));
        } else {
            header("HTTP/1.0 500 Server Error");
        }
    }

    public function show()
    {
        $data['form_data'] = $this->form_model->all_news();
        $this->load->view('view', $data);
    }

    public function ajax_get_news_by_limit()
    {
        $limit = $this->input->post('offer_start_limit');
        print_r($this->form_model->get_news_by_ajax($limit));
    }

    public function news_details($news_id)
    {
        $data['news_details'] = $this->form_model->news_details($news_id);
        $this->load->view('news', $data);
    }

    public function news_details_by_modal()
    {
        //echo "<script>alert(ok)</script>";

        $newsData = $this->input->post('newsData');
        if(isset($newsData) and !empty($newsData)){
            //echo $newsData; die();
            $row = $this->form_model->news_details($newsData);
            $output = '';

                $output .= '
						    <h4 class="text-center">'.$row->news_title.'</h4>
						    <br>
						    <div class="row">
						        <div class="col-sm-4">
						            <div class="card w-100">
                                        <div class="card-body">
                                           <img width="100%" src="'.base_url().$row->news_image_location.'" alt="No Image">
                                        </div>
                                    </div>
                                </div>
						        <div class="col-sm-8">
						            <p>'.$row->news_details.'</p>
                                </div>
                            </div>
						    
                            <br>
                            <p class="text-muted">'.$row->news_created_date_time.'</p>';
            echo $output;
        }
        else {
            echo '<ul class="list-group"><li class="list-group-item">'.'Select a News'.'</li></ul>';
        }

    }

    public function news_delete($news_id)
    {
      $this->form_model->news_delete($news_id);
      $this->session->set_flashdata('news', 'News deleted successfully..!');
      redirect('Form/show');
    }

    public function news_edit($news_id)
    {
        $this->form_validation->set_rules('news_title', 'News Title', 'trim|required|min_length[5]');
        $this->form_validation->set_rules('news_details', 'News Description', 'trim|required|min_length[10]');

        $d = $this->form_model->news_details($news_id);
        $target_file = $d->news_image_location;
        if ($this->form_validation->run() == FALSE)
        {
            $data['news_details'] = $this->form_model->news_details($news_id);
            $this->load->view('edit_news', $data);
        }else{
            if(!empty($_FILES['news_image_location']['name'])){
                $target_dir = "asset/image/";
                $target_file = $target_dir . basename($_FILES["news_image_location"]["name"]);
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                    && $imageFileType != "gif" ) {

                    $this->session->set_flashdata('image_message', 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
                    redirect('Form/insert');
                }else {
                    if (move_uploaded_file($_FILES["news_image_location"]["tmp_name"], $target_file)) {
                        $insert = $this->form_model->update($target_file, $news_id);
                        if($insert){
                            $this->session->set_flashdata('image_message', 'News Updated Successfully.');
                            redirect('Form/show');
                        }
                    } else {
                        $this->session->set_flashdata('image_message', 'Sorry, Something wrong. Please try again');
                        redirect('Form/insert');
                    }
                }
            }else{
                //$target_file = '';
                if($this->input->post('null_data') == 1){
                    $target_file_path = "";
                }else{
                    $target_file_path = $target_file;
                }
                //echo $target_file_path; die();
                $insert = $this->form_model->update($target_file_path, $news_id);
                if($insert){
                    $this->session->set_flashdata('image_message', 'News Updated Successfully.');
                    redirect('Form/show');
                }
            }
        }

        $accepted_origins = array("http://localhost");
        $imageFolder = "asset/image/";
        reset ($_FILES);
        $temp = current($_FILES);
        if (is_uploaded_file($temp['tmp_name'])){
            if (isset($_SERVER['HTTP_ORIGIN'])) {
                // same-origin requests won't set an origin. If the origin is set, it must be valid.
                if (in_array($_SERVER['HTTP_ORIGIN'], $accepted_origins)) {
                    header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
                } else {
                    header("HTTP/1.0 403 Origin Denied");
                    return;
                }
            }

            if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
                header("HTTP/1.0 500 Invalid file name.");
                return;
            }
            // Verify extension
            if (!in_array(strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION)), array("gif", "jpg", "png", "jpeg"))) {
                header("HTTP/1.0 500 Invalid extension.");
                return;
            }

            $filetowrite = $imageFolder . $temp['name'];
            move_uploaded_file($temp['tmp_name'], $filetowrite);
            echo json_encode(array('location' => $filetowrite));
        } else {
            header("HTTP/1.0 500 Server Error");
        }

    }

    public function multiple_file_upload(){
        if(is_array($_FILES)) {
            foreach ($_FILES['multiple_image_location']['name'] as $name => $value){
                if(is_uploaded_file($_FILES['multiple_image_location']['tmp_name'][$name])) {
                    $sourcePath = $_FILES['multiple_image_location']['tmp_name'][$name];
                    $targetPath = "asset/image/".$_FILES['multiple_image_location']['name'][$name];
//                    if(move_uploaded_file($sourcePath,$targetPath)) {
//                        $this->form_model->upload_multiple_file($targetPath);
//                    }
                    echo $targetPath;
                    echo $sourcePath;
                }
            }
            echo "Upload Successfull";
        }
    }

}