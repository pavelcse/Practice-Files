<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News Form</title>

    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.css">
    <script src="<?php echo base_url();?>asset/js/jquery.js"></script>
    <script src="<?php echo base_url();?>asset/js/bootstrap.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h3 class="text-center mt-5">News</h3>
            <hr>

            <a class="btn btn-sm btn-info float-right mb-2 ml-2" href="<?php echo base_url();?>Form/show">Back to List</a>
            <a class="btn btn-sm btn-info float-right mb-2 ml-2" href="<?php echo base_url()?>Form/news_edit/<?php echo $this->uri->segment(3); ?>">Edit News</a>
            <table class="table table-bordered">
                <tr>
                    <th>Image</th>
                    <td class="text-center"><img width="30%"  src="<?php echo base_url().$news_details->news_image_location; ?>" alt="Null"></td>
                </tr>
                <tr>
                    <th>Title</th>
                    <td><?php echo $news_details->news_title; ?></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><?php echo $news_details->news_details; ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
</body>
</html>