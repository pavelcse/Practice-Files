<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Color extends CI_Controller {

    public function index()
    {
        $this->load->view('color_view');
    }

    public function insert_color()
    {
        $this->form_validation->set_rules('color', 'Color', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('color_view');
        }else{
            if ($this->color_model->insert_color()){
                $this->session->set_flashdata('message', 'Color Inserted....!');
                redirect('index');
            }else{
                $this->session->set_flashdata('message', 'Color Not Inserted, Please Try Again....!');
                redirect('index');
            }
        }
    }
}
