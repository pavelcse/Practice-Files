<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class color_model extends CI_Model {

    public function insert_color()
    {
        $color =
            [
                'color' => $this->input->post('color')
            ];

        $result = $this->db->insert('colors', $color);
        return $result;
    }
}
