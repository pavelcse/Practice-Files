# CodeIgniter Load More Ajax
    Load More Ajax Codeigniter

# CSRF TOKEN
    enabled

# USERNAME AND PASSWORD
    admin : admin

# LOAGIN ADMIN
    http://localhost/folder-project/admin/login

# DEMO SITE
    http://smkti.hol.es

# SETTING TAMBAHAN
    edit footer.php di /application/views/footer.php
    di bagian ajax diganti sesuia path project masing-masing
    bagian ini :  var url = 'http://localhost/~maulayyacyber/crud_ci/'