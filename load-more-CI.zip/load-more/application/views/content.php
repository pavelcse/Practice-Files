    <div class="container">

      <div class="row">

          <div id="berita"></div>

      </div> 

      <div class="row">
          <div class="container" style="text-align: center">
            <button class="btn btn-success" id="load_more" data-val = "0" >More Berita </button>
          </div>
      </div>      

      <hr>