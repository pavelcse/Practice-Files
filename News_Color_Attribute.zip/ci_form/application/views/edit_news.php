<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News Form</title>

    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.css">
    <script src="<?php echo base_url();?>asset/js/jquery.js"></script>
    <script src="<?php echo base_url();?>asset/js/bootstrap.js"></script>

    <script src="<?php echo base_url();?>asset/ckeditor/ckeditor.js"></script>
    <script src="<?php echo base_url();?>asset/jquery-validation/dist/jquery.validate.js"></script>
    <style>
        img{
            max-width:220px;
        }
        input[type=file]{
            padding:10px;
        }
        label.error { float: none; color: red; }
    </style>

</head>
<body>
<div class="container">
    <div class="row">
        <hr>
        <h4 style="margin-left: 45%">Edit News</h4>
        <div class="col-sm-12 d-flex justify-content-center">

            <small class="text-danger"><?php echo validation_errors(); ?></small>
            <?php
            if ($this->session->flashdata('image_message'))
            {
                echo '<small class="text-danger">'.$this->session->flashdata('image_message').'</small>';
            }
            ?>
            <?php echo form_open_multipart('form/news_edit/'.$this->uri->segment(3).'', ['class'=>'w-100', 'id'=>'form', 'onsubmit'=>'return validateForm()']); ?>

            <div class="form-group">
                <?php echo form_label('News Title'); ?>
                <?php echo form_input(['name'=>'news_title', 'id'=>'news_title', 'class'=>'form-control', 'value'=> ''.$news_details->news_title.'' ]); ?>
                <span id='title_result'></span>
                <span class="error_form" id="news_title"></span>
            </div>

            <div class="form-group">
                <?php echo form_label('News Description'); ?>
                <?php echo form_textarea(['name'=>'news_details', 'class'=>'form-control', 'id'=>'news_details', 'value'=> ''.$news_details->news_details.'']); ?>
                <script>
                    CKEDITOR.replace( 'news_details' );
                </script>
            </div>
            <div class="form-group">
                <?php echo form_label('Cover Photo'); ?>
                <?php //echo form_upload(['name'=>'news_image_location', 'id'=>'files', 'class'=>'form-control-file']); ?>
                <?php echo form_upload(['name'=>'news_image_location', 'class'=>'form-control-file fileUpload', 'id'=>'files', 'accept'=>'image/jpeg, image/jpg']); ?>

                <div class="upload-demo">
                    <div class="upload-demo-wrap"><img width="150px" alt="" class="portimg" src="#"></div>
                </div>

                <script>
                    document.getElementById('files').onchange = function () {
                        result = imgremove();

                    };
                </script>

                <!--  Image Preview and Delete  -->
                    <?php if(!empty($news_details->news_image_location)):?>
                        <img src="<?php echo base_url().$news_details->news_image_location;?>" id="output_image" content="<?php echo $news_details->news_image_location;?>"/>
                        <br>
                        <button onclick="imgremove()" class="btn btn-danger btn-sm" type="button" id="Remove">Delete</button>
                    <?php endif;?>

                    <input type="hidden" name="null_data" value="" id="null_data">
                <!-- End: Image Preview and Delete  -->
            </div>
            <hr>
            <?php echo form_submit(['value'=>'Update News', 'class'=>'btn btn-info btn-sm my-3 float-right']); ?>

            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<!--Uploaded Image Preview and Delete -->
<script>

    function imgremove()
    {
        document.getElementById('output_image').removeAttribute('src');
        document.getElementById('null_data').setAttribute('value', '1');
        $("#Remove").hide();
    }

    $('#Remove').click(function(){
        $.ajax({
            type: 'POST',
            url: '<?php echo site_url('Form/news_edit');?>',
            data: {src: null}
        });
    });



</script>
<!--Image Preview and Delete-->
<script>
    // $(document).ready(function() {
    //     if (window.File && window.FileList && window.FileReader) {
    //         $("#files").on("change", function(e) {
    //             var files = e.target.files,
    //                 filesLength = 1;
    //             for (var i = 0; i < filesLength; i++) {
    //                 var f = files[i]
    //                 var fileReader = new FileReader();
    //                 fileReader.onload = (function(e) {
    //                     var file = e.target;
    //                     $("<span class=\"pip\">" +
    //                         "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
    //                         "<br/><span onclick=\"delImg()\" class=\"remove btn btn-danger btn-sm\">Delete image</span>" +
    //                         "</span>").insertAfter("#files");
    //                     $(".remove").click(function(){
    //                         $(this).parent(".pip").remove();
    //                     });
    //
    //                 });
    //                 fileReader.readAsDataURL(f);
    //             }
    //         });
    //     } else {
    //         alert("Your browser doesn't support to File API")
    //     }
    // });
    //
    // function delImg()
    // {
    //     $("#files").val('');
    // }
</script>
<script>
    function readURL() {
        var $input = $(this);
        var $newinput =  $(this).parent().parent().parent().find('.portimg ');
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                reset($newinput.next('.delbtn'), true);
                $newinput.attr('src', e.target.result).show();
                $newinput.after('<input type="button" class="delbtn removebtn btn btn-sm btn-danger" value="Delete">');
            }
            reader.readAsDataURL(this.files[0]);
        }
    }
    $(".fileUpload").change(readURL);
    $("form").on('click', '.delbtn', function (e) {
        reset($(this));
    });

    function reset(elm, prserveFileName) {
        if (elm && elm.length > 0) {
            var $input = elm;
            $input.prev('.portimg').attr('src', '').hide();
            if (!prserveFileName) {
                $($input).parent().parent().parent().find('input.fileUpload ').val("");
                //input.fileUpload and input#uploadre both need to empty values for particular div
            }
            elm.remove();
        }
    }
</script>

<!--Unique Title Check-->
<script>
    $(document).ready(function(){
        $('#news_title').blur(function(){
            var news_title = $(this).val();
            if(news_title !='')
            {
                $.ajax({
                    url: "<?php echo base_url()?>Form/check_title",
                    method: "POST",
                    data: {news_title:news_title},
                    success: function(data){
                        $('#title_result').html(data);
                    }
                });
            }
        });
    });
</script>

<!--    validations-->

<script>
    $('#form').validate({
        ignore: [],
        debug: false,
        rules: {
            news_title: {
                required: true,
            },
            news_details:{
                required: function()
                {
                    CKEDITOR.instances.news_details.updateElement();
                },

                minlength:10
            },
            news_created_date_time: {
                required: true,
            }
        }
    });
</script>

</body>
</html>