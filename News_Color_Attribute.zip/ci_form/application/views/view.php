<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News Form</title>

    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.css">
    <script src="<?php echo base_url();?>asset/js/jquery.js"></script>
    <script src="<?php echo base_url();?>asset/js/bootstrap.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-12 text-center">
            <h3 class="text-center mt-5">News</h3>
            <hr>
            <?php  if($this->session->flashdata('news')): ?>
                <span class="text-danger">
                    <?php echo $this->session->flashdata('news'); ?>
                </span>
            <?php endif; ?>

            <?php
            if ($this->session->flashdata('image_message'))
            {
                echo '<small class="text-danger">'.$this->session->flashdata('image_message').'</small>';
            }
            ?>
            <a class="btn btn-sm btn-info float-right mb-2" href="<?php echo base_url();?>Form/insert">Create News</a>
            <table class="table table-bordered text-center" id="table_message">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                </thead>

                <tbody>
                <?php foreach($form_data as $data):?>

                    <tr>
                        <td>
                            <img width="100px" height="100px" src="<?php echo base_url().$data->news_image_location; ?>" alt="No Image Uploaded">
                        </td>
                        <td><?php echo $data->news_title; ?></td>
                        <td><?php echo $data->news_created_date_time; ?></td>
                        <td>
                            <a onclick='newsDetails(<?php echo json_encode($data, JSON_HEX_APOS); ?>,event)' class="btn" href="#" id="<?php echo $data->news_id; ?>">
                                <img width="35px" src="<?php echo base_url()?>asset/icon/view.png" alt="View">
                            </a>
                            <a href="<?php echo base_url()?>Form/news_edit/<?php echo $data->news_id; ?>">
                                <img width="35px" src="<?php echo base_url()?>asset/icon/edit.png" alt="Edit">
                            </a>
                            <a href="<?php echo base_url()?>Form/news_delete/<?php echo $data->news_id; ?>">
                                <img width="35px" src="<?php echo base_url()?>asset/icon/remove.png" alt="Delete">
                            </a>
                        </td>
                    </tr>

                <?php endforeach; ?>
                </tbody>
            </table>
            <button class="btn btn-secondary my-5 btn-load-more"> See More </button>
        </div>
    </div>

    <div class="modal fade" id="news_modal" tabindex="-1" role="dialog"
         aria-labelledby="basicModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-left" id="myModalLabel">News Details</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col text-center">
                            <h4 class="text-center" id="news_title"></h4>
                            <br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4 card ml-2">
                            <div class="card-body text-center">
                                <span id="news_image"></span>
                            </div>
                        </div>
                        <div class="col-6">
                            <span id="news_description"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <br>
                            <p class="text-muted" id="news_date"></p>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>


</div>



<script type="text/javascript">

    function newsDetails(msg_array, event) {

        console.log(msg_array);

        event.preventDefault();
        $('#news_title').html("");
        $('#news_image').html("");
        $('#news_description').html("");
        $('#news_date').html("");

        var img = msg_array['news_image_location'];
        $('#news_title').html(msg_array['news_title']);
        $('#news_image').html('<img width = "150px" class="img-product" src="<?php echo base_url();?>'+img+'" alt="No Image Uploaded">');
        $('#news_description').html(msg_array['news_details']);
        $('#news_date').html(msg_array['news_created_date_time']);


        $('#news_modal').modal('show');
    }

    var stating_message_list = '<?php echo DEFAULT_DATA_LIMIT ?>';
    $('.btn-load-more').click(function () {

        $.ajax({
            type: 'POST',
            url: '<?php echo site_url('ajax_get_news_data');?>',
            data: {offer_start_limit: stating_message_list},

            success: function (result) {
                //alert(result);
                var message = $.parseJSON(result);

                //console.log(message);
                total_message = message.length;
                for (var i = 0; i < total_message; i++) {

                    $('#table_message').find('tbody').append("<tr>\n" +
                        "                    <td>" + "<img width='100px' src='<?php echo base_url()?>"+message[i]['news_image_location']+"' alt='No Image Uploaded'>" + "</td>\n" +
                        "                    <td>" + message[i]['news_title'] + "</td>\n" +
                        "                    <td>" + message[i]['news_created_date_time'] + "</td>\n" +
                        "                    <td>" +
                        "                           <a href='#' class='btn' onclick='newsDetails(" + JSON.stringify(message[i]) + ",event)'><img width='35px' src='<?php echo base_url()?>asset/icon/view.png' alt='Null'></a>\n" +
                        "                           <a href=\"<?php echo base_url()?>Form/news_edit/"+message[i]['news_id']+"\"><img width='35px' src='<?php echo base_url()?>asset/icon/edit.png' alt='Null'></a>\n" +
                        "                           <a href=\"<?php echo base_url()?>Form/news_delete/"+message[i]['news_id']+"\"><img width='35px' src='<?php echo base_url()?>asset/icon/remove.png' alt='Null'></a>\n" +
                        "                       </td>\n" +
                        "                </tr>");
                }
                stating_message_list = parseInt(stating_message_list, 10) +<?php echo DEFAULT_DATA_LIMIT?>;
            },
            error: function (error) {
                console.log(error);
                alert(2);
            }
        });

    });
</script>


</body>
</html>