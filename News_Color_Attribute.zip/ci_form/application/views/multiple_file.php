<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>News Form Multiple File</title>

    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.css">
    <script src="<?php echo base_url();?>asset/js/jquery.js"></script>
    <script src="<?php echo base_url();?>asset/js/bootstrap.js"></script>
</head>
<body>
<div class="container">
    <div class="row pt-3">
        <h4>Create New News</h4>
        <hr>
        <br>
        <div class="d-block">
            <a class="btn btn-sm btn-info float-right mb-2 ml-2" href="<?php echo base_url();?>Form/show">Go to List</a>
        </div>
        <div class="col-sm-12 d-flex justify-content-center">
            <small class="text-danger"><?php echo validation_errors(); ?></small>
            <?php
            if ($this->session->flashdata('image_message'))
            {
                echo '<small class="text-danger">'.$this->session->flashdata('image_message').'</small>';
            }
            ?>

            <?php echo form_open_multipart('form/multiple_file_upload', ['class'=>'w-100', 'id'=>'form']); ?>

            <div class="form-group">
                <?php echo form_label('Cover Photo'); ?>
                <?php echo form_upload(['name'=>'multiple_image_location[]', 'class'=>'form-control-file']); ?>
                <?php echo form_upload(['name'=>'multiple_image_location[]', 'class'=>'form-control-file']); ?>
                <?php echo form_upload(['name'=>'multiple_image_location[]', 'class'=>'form-control-file']); ?>
                <?php echo form_upload(['name'=>'multiple_image_location[]', 'class'=>'form-control-file']); ?>
            </div>

            <?php echo form_submit(['value'=>'Add File', 'class'=>'btn btn-info pool-right btn-sm my-3']); ?>

            <?php echo form_close(); ?>

        </div>
    </div>
</div>

<script>

</script>

</body>
</html>